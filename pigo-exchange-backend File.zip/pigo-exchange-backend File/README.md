# PIGO Exchange Backend

## Quick Start

1. Install: `npm install`
2. Setup .env: `cp .env.example .env`
3. Run: `npm run dev`

Server runs on: http://localhost:5000